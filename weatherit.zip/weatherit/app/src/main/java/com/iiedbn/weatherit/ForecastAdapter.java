package com.iiedbn.weatherit;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.ForecastViewHolder> {

    ArrayList<Forecast> forecasts;

    public static class ForecastViewHolder extends RecyclerView.ViewHolder {

        public ImageView icon;
        public TextView date;
        public TextView temperature;

        public ForecastViewHolder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.imv_icon);
            date = itemView.findViewById(R.id.tv_date);
            temperature = itemView.findViewById(R.id.tv_temperatures);
        }
    }

    public ForecastAdapter(ArrayList<Forecast> forecasts) {
        this.forecasts = forecasts;
    }
    @NonNull
    @Override
    public ForecastViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forecast_item, parent, false);
        ForecastViewHolder forecastViewHolder = new ForecastViewHolder(view);
        return forecastViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ForecastViewHolder holder, int position) {
        Forecast fc = forecasts.get(position);
        new ImageLoadTask(fc.getImageURL(), holder.icon);
        holder.date.setText(fc.getDate());
        holder.temperature.setText(String.format("%s°C \\ %s°C", fc.getMaxTemp(), fc.getMinTemp()));
    }

    @Override
    public int getItemCount() {
        return forecasts.size();
    }
}
